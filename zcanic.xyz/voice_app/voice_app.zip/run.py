#!/usr/bin/env python
"""
Zcanic Voice Service 快速启动脚本
语音服务目录入口点
"""
import sys
from voice_app.run_service import main

if __name__ == "__main__":
    sys.exit(main()) 